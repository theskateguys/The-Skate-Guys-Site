# The Skate Guys - uncommitted merch transfer

Prepared 6 November 2026 (America/Port_of_Spain). This ZIP preserves five source files byte-for-byte; it is not a deployable website.

Original workspace: C:\Users\infot\OneDrive\Documents\Dylon
Original branch: codex/single-session-booking-flow
Current checkout/base commit: b44308afacdca191ab442b6b8c7dadae65965479
Committed merch.html baseline: e17b53b4cef7a86a288dbdba4ccca8aa356d93b9 (Git blob).
The same committed merch.html exists at 0aadc8db55a7ad8bd0db33e3cc13cd35250c5829 on origin/codex/merch-visual-upgrade.
Repository: https://github.com/theskateguys/The-Skate-Guys-Site

## Exact original paths

- C:\Users\infot\OneDrive\Documents\Dylon\merch.html
- C:\Users\infot\OneDrive\Documents\Dylon\assets\merch\charcoal-grey-dtf-print.png
- C:\Users\infot\OneDrive\Documents\Dylon\assets\merch\white-dtf-print.png
- C:\Users\infot\OneDrive\Documents\Dylon\assets\merch\heather-grey-dtf-print.png
- C:\Users\infot\OneDrive\Documents\Dylon\assets\merch\navy-dtf-print.png

ZIP paths preserve paths relative to that workspace. README.md is the only additional entry.

## What the draft changes

One Community Tee card gains arrows/colour controls in this order: Black (default), Charcoal Grey, White, Heather Grey, Navy. Image, alt text and colour label update together. Navy is an approximation using CSS tone adjustment. Shopify buttons still open the general store; colour is not connected to a Shopify variant.

The existing black-dtf-print.png is deliberately excluded: it is already committed at 0aadc8db55a7ad8bd0db33e3cc13cd35250c5829. Other existing site assets are also excluded.

## Receiving instructions

Extract into a separate review directory first. Compare the modified merch.html against the baseline above. Do not overwrite a current checkout. Port only the intended merch changes when authorized: this whole file comes from an older website context and can reintroduce retired copy/lead forms if copied onto the live WhatsApp release.

No Git metadata, Codex settings, logs, credentials, customer records, or other workspace files are included. Original files remain uncommitted and unchanged. This archive grants no merge, deployment or external-system-change authority.